﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor (typeof (Masking))]
public class DareerMashkingEditor : Editor {

    SerializedProperty stop;

    SerializedProperty paintAlphaValue;
    SerializedProperty isInitialAlphaZero;

    SerializedProperty isFollowObject;
    SerializedProperty objectToFollow;
    SerializedProperty paintLayerMask;

    SerializedProperty drawMode;
    SerializedProperty customBrushes;
    SerializedProperty selectedBrush;
    SerializedProperty useAdditiveColors;
    SerializedProperty brushSize;

    SerializedProperty realTimeTexUpdate;
    SerializedProperty textureUpdateSpeed;

    void OnEnable ( ) {
        // Setup the SerializedProperties.
        stop = serializedObject.FindProperty ("stop");

        paintLayerMask = serializedObject.FindProperty ("paintLayerMask");
        paintAlphaValue = serializedObject.FindProperty ("paintAlphaValue");
        isInitialAlphaZero = serializedObject.FindProperty ("isInitialAlphaZero");

        isFollowObject = serializedObject.FindProperty ("isFollowObject");
        objectToFollow = serializedObject.FindProperty ("objectToFollow");

        drawMode = serializedObject.FindProperty ("drawMode");
        useAdditiveColors = serializedObject.FindProperty ("useAdditiveColors");
        brushSize = serializedObject.FindProperty ("brushSize");
        customBrushes = serializedObject.FindProperty ("customBrushes");
        selectedBrush = serializedObject.FindProperty ("selectedBrush");

        realTimeTexUpdate = serializedObject.FindProperty ("realTimeTexUpdate");
        textureUpdateSpeed = serializedObject.FindProperty ("textureUpdateSpeed");
    }

    public override void OnInspectorGUI ( ) {
        // Update the serializedProperty - always do this in the beginning of OnInspectorGUI.
        serializedObject.Update ();

        GUILayout.BeginVertical();
        EditorGUILayout.PropertyField (paintLayerMask, new GUIContent ("Paint Mask Layer: "), true);
        
        EditorGUILayout.PropertyField (stop, new GUIContent ("Stop System:"), true);
        EditorGUILayout.PropertyField (isInitialAlphaZero, new GUIContent ("Is Initial Transparent:"), true);
        GUILayout.EndVertical();

        GUILayout.BeginHorizontal ();
        EditorGUILayout.IntSlider (paintAlphaValue, 0, 255, new GUIContent ("Brush Alpha Value: "));
        GUILayout.EndHorizontal ();
    
        //for brushing
        GUILayout.BeginVertical();
        EditorGUILayout.PropertyField (drawMode, new GUIContent ("Brush Mode: "), true);
        EditorGUILayout.PropertyField (isFollowObject, new GUIContent ("Brush through Tool:"), true);
        if (isFollowObject.boolValue == true)
            EditorGUILayout.PropertyField (objectToFollow, new GUIContent ("Object To Follow: "), true);

        EditorGUILayout.PropertyField (useAdditiveColors, new GUIContent ("Additive Mode: "), true);

        if(drawMode.enumValueIndex == 0){
            EditorGUILayout.PropertyField (brushSize, new GUIContent ("Brush Size: "), true);
        }
        else {
            EditorGUILayout.PropertyField (customBrushes, new GUIContent ("Array Of Custom Brushes: "), true);
            EditorGUILayout.PropertyField (selectedBrush, new GUIContent ("Brush Index: "), true);
        }
        GUILayout.EndVertical();
        //------------

        //for texture updating
        GUILayout.Space(10);
        GUILayout.BeginVertical();
        EditorGUILayout.PropertyField (realTimeTexUpdate, new GUIContent ("Runtime Texture Update: "), true);
        if(realTimeTexUpdate.boolValue == true)
            EditorGUILayout.PropertyField (textureUpdateSpeed, new GUIContent ("Updating Speed: "), true);
        GUILayout.EndVertical();
        //------------

        // Apply changes to the serializedProperty - always do this in the end of OnInspectorGUI.
        serializedObject.ApplyModifiedProperties ();
    }
}