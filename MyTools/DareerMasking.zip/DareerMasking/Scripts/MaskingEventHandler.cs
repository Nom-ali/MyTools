﻿using System;
using UnityEngine;

public class MaskingEventHandler : MonoBehaviour 
{

	public Action OnComplete;

	[SerializeField]
	private bool OnCompleteResetImage = false;

    [SerializeField]
	private float CompletePercentage = 80; 
  
	private float CoinsPercentage = 0f;
	

	void OnEnable ( ) {
		GetComponent<Masking> ().OnPixelsChange += OnPresentagePixelsChange;
	}

	void OnDisable ( ) {
		GetComponent<Masking> ().OnPixelsChange -= OnPresentagePixelsChange;
	}
	
	void OnPresentagePixelsChange (float x) {
		Debug.Log ("precentageDone % = " + x);
		if (x >= CompletePercentage && OnCompleteResetImage)
		{
			GetComponent<ChangeSprites>().ResetSprite();
			GetComponent<Masking>().stop = true;
			GetComponent<Masking>().enabled = false;
			OnComplete?.Invoke();
        }
		else if(x >= CoinsPercentage && GameManager.instance.ColorsCoin == false)
		{
			GameManager.instance.CoinsUpdate(25);
			GameManager.instance.ColorsCoin = true;
        }
	}
}
