
using UnityEngine;
using UnityEngine.EventSystems;


[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
public class Masking : MonoBehaviour
{

    public enum EarsingMode
    {
        Default,
        CustomBrush
    }

    public delegate void OnAplhaChange(float precentageDone);

    public bool stop;

    [Range(0f, 255f)]
    public byte paintAlphaValue;

    public bool isInitialAlphaZero;

    public bool isFollowObject;

    public Transform objectToFollow;

    [Space(10f)]
    public LayerMask paintLayerMask = 1;

    [Header("Brushing Mode")]
    public EarsingMode drawMode;

    [Header("For Custom Brushes")]
    public Texture2D[] customBrushes;

    public int selectedBrush;

    private byte[] customBrushBytes;

    private int customBrushWidth;

    private int customBrushHeight;

    private int customBrushWidthHalf;

    private int texWidthMinusCustomBrushWidth;

    private int texHeightMinusCustomBrushHeight;

    private float scaleAdjust = 1f;

    private const float BASE_WIDTH = 800f;

    private const float BASE_HEIGHT = 480f;

    public bool useAdditiveColors;

    [Header("For Default Brushes")]
    public int brushSize = 24;

    private int brushSizeX1 = 48;

    private int brushSizeXbrushSize = 576;

    private int brushSizeX4 = 96;

    private int brushSizeDiv4 = 6;

    [Space(10f)]
    public bool realTimeTexUpdate = true;

    public float textureUpdateSpeed = 0.1f;

    private float nextTextureUpdate;

    private float brushAlphaStrength = 0.01f;

    private float brushAlphaStrengthVal = 0.01f;

    private float brushAlphaLerpVal = 0.1f;

    [Space(10f)]
    private string targetTexture = "_MainTex";

    private FilterMode filterMode = FilterMode.Point;
    Color32 clearColor = new Color32 (255, 255, 255, 255);

    private int texWidth;

    private int texHeight;

    private Touch touch;

    private bool wasTouching;

    private RaycastHit hit;

    private bool wentOutside;

    private bool usingClearingImage;

    private Vector2 pixelUV;

    private Vector2 pixelUVOld;

    private Vector2[] pixelUVs;

    private Vector2[] pixelUVOlds;

    private bool textureNeedsUpdate;

    private Camera myCamera;

    private Renderer myRenderer;

    private LineRenderer lineRenderer;

    private EventSystem eventSystem;

    private byte[] pixels;

    private int pixelsLength;

    private byte[] clearPixels;

    private Texture2D drawingTexture;

    private Vector3 pointerPosition;

    private int pixelAlphaZero_Count;

    private int i;

    public event OnAplhaChange OnPixelsChange;

    public void _Awake()
    {
        myCamera = Camera.main;
        myRenderer = GetComponent<Renderer>();
        GameObject gameObject = GameObject.Find("EventSystem");
        if (gameObject == null)
        {
            Debug.LogWarning("GameObject EventSystem is missing from scene. So, creating a new one for working!");
            gameObject = new GameObject();
            gameObject.name = "EventSystem";
            gameObject.AddComponent(typeof(EventSystem));
            gameObject.AddComponent(typeof(StandaloneInputModule));
            eventSystem = gameObject.GetComponent<EventSystem>();
        }
        else
        {
            eventSystem = gameObject.GetComponent<EventSystem>();
        }

        StartingCheckingUp();
        InitializeEverything();
    }

    private void StartingCheckingUp()
    {
        if (myCamera == null)
        {
            Debug.LogError("MainCamera not founded, you must have 1 camera active & tagged as MainCamera", base.gameObject);
        }

        if (drawMode == EarsingMode.CustomBrush && (customBrushes == null || customBrushes.Length < 1))
        {
            Debug.LogWarning("CustomBrushes is enabled, but no custombrushes assigned to array, disabling customBrushes", base.gameObject);
            drawMode = EarsingMode.Default;
        }

        if (!myRenderer.material.HasProperty(targetTexture))
        {
            Debug.LogError("Fatal error: Current shader doesn't have a property: '" + targetTexture + "'", base.gameObject);
        }

        if (paintLayerMask.value == 0)
        {
            Debug.LogWarning("paintLayerMask is set to 'nothing', assign same layer where the drawing canvas is", base.gameObject);
        }
    }

    private void InitializeEverything()
    {
        SetBrushSize(brushSize);
        SetPaintColor(paintAlphaValue);
        SetBrushAlphaStrength(brushAlphaStrength);
        float num = 0.00208333344f;
        _ = Screen.height;
        _ = scaleAdjust;
        pixelUVs = new Vector2[20];
        pixelUVOlds = new Vector2[20];
        if (GetComponent<MeshCollider>() == null)
        {
            Debug.LogError("MeshCollider is missing, won't be able to raycast to canvas object");
        }

        if (GetComponent<MeshFilter>() == null || GetComponent<MeshFilter>().sharedMesh == null)
        {
            Debug.LogWarning("Mesh or MeshFilter is missing, won't be able to see the canvas object");
        }

        if (myRenderer.material.GetTexture(targetTexture) == null && !usingClearingImage)
        {
            if (drawingTexture != null)
            {
                UnityEngine.Object.DestroyImmediate(drawingTexture, allowDestroyingAssets: true);
            }

            drawingTexture = new Texture2D(texWidth, texHeight, TextureFormat.RGBA32, mipChain: false);
            myRenderer.material.SetTexture(targetTexture, drawingTexture);
            pixels = new byte[texWidth * texHeight * 4];
        }
        else
        {
            usingClearingImage = true;
            texWidth = myRenderer.material.GetTexture(targetTexture).width;
            texHeight = myRenderer.material.GetTexture(targetTexture).height;
            pixels = new byte[texWidth * texHeight * 4];
            if (drawingTexture != null)
            {
                UnityEngine.Object.DestroyImmediate(drawingTexture, allowDestroyingAssets: true);
            }

            drawingTexture = new Texture2D(texWidth, texHeight, TextureFormat.RGBA32, mipChain: false);
            ReadClearingImage();
            myRenderer.material.SetTexture(targetTexture, drawingTexture);
        }

        pixelsLength = pixels.Length;
        drawingTexture.filterMode = filterMode;
        drawingTexture.wrapMode = TextureWrapMode.Clamp;
        if (drawMode == EarsingMode.CustomBrush)
        {
            ReadCurrentCustomBrush();
        }

        ClearImage(updateUndoBuffer: false);
        if (isInitialAlphaZero)
        {
            ClearImageWithAlphaZero();
        }
    }

    private void Update()
    {
        if (!stop)
        {
            MousePaint();
            if (textureNeedsUpdate && (realTimeTexUpdate || Time.time > nextTextureUpdate))
            {
                nextTextureUpdate = Time.time + textureUpdateSpeed;
                UpdateTexture();
            }
        }
    }

    private void MousePaint()
    {
        if (Input.GetMouseButton(0))
        {
            if (eventSystem.IsPointerOverGameObject() || eventSystem.currentSelectedGameObject != null)
            {
                return;
            }

            if (isFollowObject)
            {
                pointerPosition = myCamera.WorldToScreenPoint(objectToFollow.transform.position);
            }
            else
            {
                pointerPosition = Input.mousePosition;
            }

            if (!Physics.Raycast(myCamera.ScreenPointToRay(pointerPosition), out hit, float.PositiveInfinity, paintLayerMask))
            {
                wentOutside = true;
                return;
            }

            pixelUVOld = pixelUV;
            pixelUV = hit.textureCoord;
            pixelUV.x *= texWidth;
            pixelUV.y *= texHeight;
            if (wentOutside)
            {
                pixelUVOld = pixelUV;
                wentOutside = false;
            }

            switch (drawMode)
            {
                case EarsingMode.Default:
                    DrawCircle((int)pixelUV.x, (int)pixelUV.y);
                    break;
                case EarsingMode.CustomBrush:
                    DrawCustomBrush((int)pixelUV.x, (int)pixelUV.y);
                    break;
            }

            textureNeedsUpdate = true;
        }

        if (Input.GetMouseButtonDown(0))
        {
            if (!Physics.Raycast(myCamera.ScreenPointToRay(pointerPosition), out hit, float.PositiveInfinity, paintLayerMask))
            {
                return;
            }

            pixelUVOld = pixelUV;
        }

        if (Input.GetMouseButtonUp(0) && this.OnPixelsChange != null)
        {
            int num = 0;
            for (int i = 3; i < pixelsLength; i += 4)
            {
                if (pixels[i].Equals(0))
                {
                    num += 4;
                }
            }

            float precentageDone = (float)(pixelsLength - num) / (float)pixelsLength * 100f;
            this.OnPixelsChange(precentageDone);
        }

        if (Vector2.Distance(pixelUV, pixelUVOld) > (float)brushSize && textureNeedsUpdate)
        {
            switch (drawMode)
            {
                case EarsingMode.Default:
                    DrawLine(pixelUVOld, pixelUV);
                    break;
                case EarsingMode.CustomBrush:
                    DrawLineWithBrush(pixelUVOld, pixelUV);
                    break;
            }

            pixelUVOld = pixelUV;
            textureNeedsUpdate = true;
        }
    }

    private void TouchPaint()
    {
        while (i < Input.touchCount)
        {
            touch = Input.GetTouch(i);
            if (eventSystem.IsPointerOverGameObject(touch.fingerId))
            {
                return;
            }

            i++;
        }

        if (eventSystem.currentSelectedGameObject != null)
        {
            return;
        }

        for (i = 0; i < Input.touchCount; i++)
        {
            touch = Input.GetTouch(i);
            if (touch.phase == TouchPhase.Began)
            {
                wasTouching = true;
            }

            if ((touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Began) && Physics.Raycast(myCamera.ScreenPointToRay(touch.position), out hit, float.PositiveInfinity, paintLayerMask))
            {
                pixelUVOlds[touch.fingerId] = pixelUVs[touch.fingerId];
                pixelUVs[touch.fingerId] = hit.textureCoord;
                pixelUVs[touch.fingerId].x *= texWidth;
                pixelUVs[touch.fingerId].y *= texHeight;
                switch (drawMode)
                {
                    case EarsingMode.Default:
                        DrawCircle((int)pixelUVs[touch.fingerId].x, (int)pixelUVs[touch.fingerId].y);
                        break;
                    case EarsingMode.CustomBrush:
                        DrawCustomBrush((int)pixelUVs[touch.fingerId].x, (int)pixelUVs[touch.fingerId].y);
                        break;
                }

                textureNeedsUpdate = true;
            }

            if (touch.phase == TouchPhase.Began)
            {
                pixelUVOlds[touch.fingerId] = pixelUVs[touch.fingerId];
            }

            if (textureNeedsUpdate)
            {
                switch (drawMode)
                {
                    case EarsingMode.Default:
                        DrawLine(pixelUVOlds[touch.fingerId], pixelUVs[touch.fingerId]);
                        break;
                    case EarsingMode.CustomBrush:
                        DrawLineWithBrush(pixelUVOlds[touch.fingerId], pixelUVs[touch.fingerId]);
                        break;
                }

                textureNeedsUpdate = true;
                pixelUVOlds[touch.fingerId] = pixelUVs[touch.fingerId];
            }
        }
    }

    private void UpdateTexture()
    {
        textureNeedsUpdate = false;
        drawingTexture.LoadRawTextureData(pixels);
        drawingTexture.Apply(updateMipmaps: false);
    }

    public void DrawCircle(int x, int y)
    {
        int pixel = 0;
        for (int i = 0; i < brushSizeX4; i++)
        {
            int tx = i % brushSizeX1 - brushSize;
            int ty = i / brushSizeX1 - brushSize;
            //if (tx * tx + ty * ty <= brushSizeXbrushSize && x + tx >= 0 && y + ty >= 0 && x + tx < texWidth && y + ty < texHeight)
            //{
            //    pixel = texWidth * (y + ty) + x + tx << 2;
            //    if (useAdditiveColors)
            //    {
            //        pixels[pixel + 3] = ByteLerp(pixels[pixel + 3], clearPixels[pixel + 3], brushAlphaLerpVal);
            //    }
            //    else
            //    {
            //        pixels[pixel + 3] = paintAlphaValue;
            //    }
            //}

            if (tx * tx + ty * ty > brushSizeXbrushSize)
                continue;
            if (x + tx < 0 || y + ty < 0 || x + tx >= texWidth || y + ty >= texHeight)
                continue; // temporary fix for corner painting

            pixel = (texWidth * (y + ty) + x + tx) << 2;

            //means if selected color alpha is opaque
            if (paintAlphaValue == 255)
                pixels[pixel + 3] = clearPixels[pixel + 3];
            else
                pixels[pixel + 3] = paintAlphaValue;
        }
    }

    public void DrawPoint(int x, int y)
    {
        int num = (texWidth * y + x) * 4;
        pixels[num + 3] = paintAlphaValue;
    }

    public void DrawPoint(int pixel)
    {
        pixels[pixel + 3] = paintAlphaValue;
    }

    public void DrawLine(int startX, int startY, int endX, int endY)
    {
        int num = endX - startX;
        int num2 = (num + (num >> 31)) ^ (num >> 31);
        num = endY - startY;
        int num3 = (num + (num >> 31)) ^ (num >> 31);
        int num4 = ((startX < endX) ? 1 : (-1));
        int num5 = ((startY < endY) ? 1 : (-1));
        int num6 = num2 - num3;
        int num7 = 0;
        while (true)
        {
            num7++;
            if (num7 > brushSizeDiv4)
            {
                num7 = 0;
                DrawCircle(startX, startY);
            }

            if (startX != endX || startY != endY)
            {
                int num8 = 2 * num6;
                if (num8 > -num3)
                {
                    num6 -= num3;
                    startX += num4;
                }
                else if (num8 < num2)
                {
                    num6 += num2;
                    startY += num5;
                }

                continue;
            }

            break;
        }
    }

    public void DrawLine(Vector2 start, Vector2 end)
    {
        DrawLine((int)start.x, (int)start.y, (int)end.x, (int)end.y);
    }

    private void DrawCustomBrush(int px, int py)
    {
        int num = px - customBrushWidthHalf;
        int num2 = py - customBrushWidthHalf;
        if (num < 0)
        {
            num = 0;
        }
        else if (num + customBrushWidth >= texWidth)
        {
            num = texWidthMinusCustomBrushWidth;
        }

        if (num2 < 1)
        {
            num2 = 1;
        }
        else if (num2 + customBrushHeight >= texHeight)
        {
            num2 = texHeightMinusCustomBrushHeight;
        }

        int num3 = texWidth * num2 + num << 2;
        int num4 = 0;
        for (int i = 0; i < customBrushHeight; i++)
        {
            for (int j = 0; j < customBrushWidth; j++)
            {
                num4 = customBrushWidth * i + j << 2;
                if (customBrushBytes[num4 + 3] > 0)
                {
                    if (useAdditiveColors)
                    {
                        pixels[num3 + 3] = ByteLerp(pixels[num3 + 3], paintAlphaValue, brushAlphaLerpVal);
                    }
                    else
                    {
                        pixels[num3 + 3] = paintAlphaValue;
                    }
                }

                num3 += 4;
            }

            num3 = (texWidth * ((num2 == 0) ? 1 : (num2 + i)) + num + 1) * 4;
        }
    }

    public void ReadCurrentCustomBrush()
    {
        customBrushWidth = customBrushes[selectedBrush].width;
        customBrushHeight = customBrushes[selectedBrush].height;
        customBrushBytes = new byte[customBrushWidth * customBrushHeight * 4];
        int num = 0;
        Color32[] pixels = customBrushes[selectedBrush].GetPixels32();
        for (int i = 0; i < customBrushHeight; i++)
        {
            for (int j = 0; j < customBrushWidth; j++)
            {
                customBrushBytes[num] = pixels[j + i * customBrushWidth].r;
                customBrushBytes[num + 1] = pixels[j + i * customBrushWidth].g;
                customBrushBytes[num + 2] = pixels[j + i * customBrushWidth].b;
                customBrushBytes[num + 3] = pixels[j + i * customBrushWidth].a;
                num += 4;
            }
        }

        customBrushWidthHalf = (int)((float)customBrushWidth * 0.5f);
        texWidthMinusCustomBrushWidth = texWidth - customBrushWidth;
        texHeightMinusCustomBrushHeight = texHeight - customBrushHeight;
    }

    private void DrawLineWithBrush(Vector2 start, Vector2 end)
    {
        int num = (int)start.x;
        int num2 = (int)start.y;
        int num3 = (int)end.x;
        int num4 = (int)end.y;
        int num5 = num3 - num;
        int num6 = (num5 + (num5 >> 31)) ^ (num5 >> 31);
        num5 = num4 - num2;
        int num7 = (num5 + (num5 >> 31)) ^ (num5 >> 31);
        int num8 = ((num < num3) ? 1 : (-1));
        int num9 = ((num2 < num4) ? 1 : (-1));
        int num10 = num6 - num7;
        int num11 = 0;
        while (true)
        {
            num11++;
            if (num11 > brushSizeDiv4)
            {
                num11 = 0;
                DrawCustomBrush(num, num2);
            }

            if (num != num3 || num2 != num4)
            {
                int num12 = 2 * num10;
                if (num12 > -num7)
                {
                    num10 -= num7;
                    num += num8;
                }
                else if (num12 < num6)
                {
                    num10 += num6;
                    num2 += num9;
                }

                continue;
            }

            break;
        }
    }

    public void ClearImage()
    {
        ClearImage(updateUndoBuffer: true);
    }

    public void ClearImage(bool updateUndoBuffer)
    {
        if (usingClearingImage)
        {
            ClearImageWithImage();
            return;
        }

        int pixel = 0;
        for (int y = 0; y < texHeight; y++)
        {
            for (int x = 0; x < texWidth; x++)
            {
                pixels[pixel] = clearColor.r;
                pixels[pixel + 1] = clearColor.g;
                pixels[pixel + 2] = clearColor.b;
                pixels[pixel + 3] = clearColor.a;
                pixel += 4;
            }
        }

        UpdateTexture();
    }

    public void ClearImageWithImage()
    {
        System.Array.Copy(clearPixels, 0, pixels, 0, clearPixels.Length);
        drawingTexture.LoadRawTextureData(clearPixels);
        drawingTexture.Apply(updateMipmaps: false);
    }

    public void ClearImageWithAlphaZero()
    {
        //made a black byte array
        byte[] arrayOfPixelsAlphaZero = new byte[clearPixels.Length];

        int pixel = 0;
        for (int y = 0; y < texHeight; y++)
        {
            for (int x = 0; x < texWidth; x++)
            {
                arrayOfPixelsAlphaZero[pixel] = pixels[pixel];
                arrayOfPixelsAlphaZero[pixel + 1] = pixels[pixel + 1];
                arrayOfPixelsAlphaZero[pixel + 2] = pixels[pixel + 2];
                arrayOfPixelsAlphaZero[pixel + 3] = 0;
                pixel += 4;
            }
        }

        // fill pixels array with clearpixels array
        System.Array.Copy(arrayOfPixelsAlphaZero, 0, pixels, 0, arrayOfPixelsAlphaZero.Length);

        // just assign our clear image array into tex
        drawingTexture.LoadRawTextureData(arrayOfPixelsAlphaZero);
        drawingTexture.Apply(false);
    }

    public void ReadClearingImage()
    {
        clearPixels = new byte[texWidth * texHeight * 4];

        //drawingTexture.SetPixels32(((Texture2D)myRenderer.material.GetTexture(targetTexture)).GetPixels32());
        //drawingTexture.Apply(updateMipmaps: false);

        Texture2D originalTexture = (Texture2D)myRenderer.material.GetTexture(targetTexture);
        drawingTexture.SetPixels32(originalTexture.GetPixels32());
        drawingTexture.Apply(updateMipmaps: false);

        Color32[] tempPixels = drawingTexture.GetPixels32();
        
        int pixel = 0;
        int tempCount = tempPixels.Length;

        for (int i = 0; i < tempCount; i++)
        {
            clearPixels[pixel] = tempPixels[i].r;
            clearPixels[pixel + 1] = tempPixels[i].g;
            clearPixels[pixel + 2] = tempPixels[i].b;
            clearPixels[pixel + 3] = tempPixels[i].a;
            pixel += 4;
        }
    }

    public Vector3 PixelToWorld(int x, int y)
    {
        Vector3 vector = new Vector3(x, y, 0f);
        float x2 = myRenderer.bounds.size.x;
        float y2 = myRenderer.bounds.size.y;
        float x3 = (vector.x / (float)texWidth - 0.5f) * x2;
        float y3 = (vector.y / (float)texHeight - 0.5f) * y2;
        return new Vector3(x3, y3, 0f);
    }

    public void SetBrushSize(int newSize)
    {
        brushSize = Mathf.Clamp(newSize, 1, 999);
        brushSizeX1 = brushSize << 1;
        brushSizeXbrushSize = brushSize * brushSize;
        brushSizeX4 = brushSizeXbrushSize << 2;
        brushSizeDiv4 = brushSize >> 2;
    }

    public void SetPaintColor(byte newColor)
    {
        paintAlphaValue = newColor;
        SetBrushAlphaStrength(brushAlphaStrength);
    }

    public void SetBrushAlphaStrength(float val)
    {
        brushAlphaStrengthVal = 255f / val;
    }

    private byte ByteLerp(byte value1, byte value2, float amount)
    {
        return (byte)((float)(int)value1 + (float)(value2 - value1) * amount);
    }

    private void OnDestroy()
    {
        if (drawingTexture != null)
        {
            UnityEngine.Object.DestroyImmediate(drawingTexture, allowDestroyingAssets: true);
        }

        pixels = null;
        clearPixels = null;
    }
}